package com.e1.nexacro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NexacroApplicationTests {

	@Test
	void contextLoads() {
	}

}
